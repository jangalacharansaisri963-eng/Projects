"""
Tests package for ScientificCalculator.
"""
